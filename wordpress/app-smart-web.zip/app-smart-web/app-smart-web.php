<?php
/**

Plugin Name: smart web REST API
Plugin URI: http://sw4ws.onlin/ 
Description: SmartWeb excels at custom design and front end development. We love taking on challenging projects that require full-on content strategy, thoughtful design, demanding development, and ongoing marketing. (rev. 2017.05.04 04:52:29)
Version: 1.0
Author: smart web 
Author URI: http://sw4ws.onlin/ 

SmartWeb excels at custom design and front end development. We love taking on challenging projects that require full-on content strategy, thoughtful design, demanding development, and ongoing marketing.

**/


/**
 * Plugin Base File
 **/
define("SMART_WEB_PATH",dirname(__FILE__));
/**
 * Plugin Base Directory
 **/
define("SMART_WEB_DIR",basename(SMART_WEB_PATH));

/**
 * You can disable RESTAPI2 only for old WP
 **/
define("SMART_WEB_RESTAPI2",true);

class AppSmartWeb{

	function __construct(){

		// File upload allowed

		$whitelist_files[] 		= array("mimetype"=>"image/jpeg","ext"=>"jpg") ; 		
		$whitelist_files[] 		= array("mimetype"=>"image/jpg","ext"=>"jpg") ; 		
		$whitelist_files[] 		= array("mimetype"=>"image/png","ext"=>"png") ; 		
		$whitelist_files[] 		= array("mimetype"=>"text/plain","ext"=>"txt") ; 		
		$this->whitelist_files = $whitelist_files;
		add_action("plugins_loaded", array($this, "app_textdomain")); //load language/textdomain
		/** register post type **/
		add_action("init", array($this, "post_type_app_barner"));
		add_action("init", array($this, "post_type_app_categorie"));
		add_action("init", array($this, "post_type_app_contact"));
		add_action("init", array($this, "post_type_app_page"));
		add_action("init", array($this, "post_type_app_post"));

          if(SMART_WEB_RESTAPI2 == true){
		    /** register rest router **/
		        add_action("rest_api_init", array($this,"register_rest_route_app_barner"));
		        add_action("rest_api_init", array($this,"register_rest_route_app_categorie"));
		        add_action("rest_api_init", array($this,"register_rest_route_app_contact"));
		        add_action("rest_api_init", array($this,"register_rest_route_app_page"));
		        add_action("rest_api_init", array($this,"register_rest_route_app_post"));

		    /** register rest router for form request **/
		        add_action("rest_api_init", array($this,"register_rest_route_app_contact_submit"));
          }else{

		    /** register ajax/ajax_nopriv_ **/
		        add_action("wp_ajax_nopriv_app_barner", array($this,"ajax_app_barner"));
		        add_action("wp_ajax_app_barner", array($this,"ajax_app_barner"));

		        add_action("wp_ajax_nopriv_app_categorie", array($this,"ajax_app_categorie"));
		        add_action("wp_ajax_app_categorie", array($this,"ajax_app_categorie"));

		        add_action("wp_ajax_nopriv_app_contact", array($this,"ajax_app_contact"));
		        add_action("wp_ajax_app_contact", array($this,"ajax_app_contact"));

		        add_action("wp_ajax_nopriv_app_page", array($this,"ajax_app_page"));
		        add_action("wp_ajax_app_page", array($this,"ajax_app_page"));

		        add_action("wp_ajax_nopriv_app_post", array($this,"ajax_app_post"));
		        add_action("wp_ajax_app_post", array($this,"ajax_app_post"));

		        add_action("wp_ajax_nopriv_app_contact_submit", array($this,"ajax_app_contact_submit"));
		        add_action("wp_ajax_app_contact_submit", array($this,"ajax_app_contact_submit"));

          }

		/** register metabox for admin **/
		if(is_admin()){
		    add_action("admin_head",array($this,"admin_head_app_smart_web"),1);
			add_action("add_meta_boxes",array($this,"metabox_app_barner"));
			add_action("save_post",array($this,"metabox_app_barner_save"));
			add_action("add_meta_boxes",array($this,"metabox_app_categorie"));
			add_action("save_post",array($this,"metabox_app_categorie_save"));
			add_action("add_meta_boxes",array($this,"metabox_app_contact"));
			add_action("save_post",array($this,"metabox_app_contact_save"));
			add_action("add_meta_boxes",array($this,"metabox_app_page"));
			add_action("save_post",array($this,"metabox_app_page_save"));
			add_action("add_meta_boxes",array($this,"metabox_app_post"));
			add_action("save_post",array($this,"metabox_app_post_save"));
		}
	}


  // Register textdomain
	function app_textdomain(){
	     load_plugin_textdomain("app-smart-web", false, SMART_WEB_DIR . "/languages");
  }
	/** register post for table barner **/
	public function post_type_app_barner()
	{
			$labels = array(
			"name" => _x("Barners", "post type general name", "app-smart-web"),
			"singular_name" => _x("Barner", "post type singular name", "app-smart-web"),
			"menu_name" => _x("Barners", "admin menu", "app-smart-web"),
			"name_admin_bar" => _x("Barners", "add new on admin bar", "app-smart-web"),
			"add_new" => _x("Add new Barners", "item", "app-smart-web"),
			"add_new_item" => __("Add new Barners", "app-smart-web"),
			"new_item" => __("new item", "app-smart-web"),
			"edit_item" => __("Edit Barners", "app-smart-web"),
			"view_item" => __("View Barners", "app-smart-web"),
			"all_items" => __("All Barners", "app-smart-web"),
			"search_items" => __("Search Barners", "app-smart-web"),
			"parent_item_colon" => __("parent Barners:", "app-smart-web"),
			"not_found" => __("not found", "app-smart-web"),
			"not_found_in_trash" => __("not found in trash", "app-smart-web"));
			$args = array(
				"labels" => $labels,
				"public" => true,
				"menu_icon" => "dashicons-tickets",
				"publicly_queryable" => false,
				"show_ui" => true,
				"show_in_menu" => true,
				"query_var" => true,
				"capability_type" => "page",
				"has_archive" => true,
				"hierarchical" => true,
				"menu_position" => null,
				"taxonomies" => array(),  
				"supports" => array("title"));
			register_post_type("app_barner", $args);
	}
	
	/** register post for table categorie **/
	public function post_type_app_categorie()
	{
			$labels = array(
			"name" => _x("Categories", "post type general name", "app-smart-web"),
			"singular_name" => _x("Categorie", "post type singular name", "app-smart-web"),
			"menu_name" => _x("Categories", "admin menu", "app-smart-web"),
			"name_admin_bar" => _x("Categories", "add new on admin bar", "app-smart-web"),
			"add_new" => _x("Add new Categories", "item", "app-smart-web"),
			"add_new_item" => __("Add new Categories", "app-smart-web"),
			"new_item" => __("new item", "app-smart-web"),
			"edit_item" => __("Edit Categories", "app-smart-web"),
			"view_item" => __("View Categories", "app-smart-web"),
			"all_items" => __("All Categories", "app-smart-web"),
			"search_items" => __("Search Categories", "app-smart-web"),
			"parent_item_colon" => __("parent Categories:", "app-smart-web"),
			"not_found" => __("not found", "app-smart-web"),
			"not_found_in_trash" => __("not found in trash", "app-smart-web"));
			$args = array(
				"labels" => $labels,
				"public" => true,
				"menu_icon" => "dashicons-tickets",
				"publicly_queryable" => false,
				"show_ui" => true,
				"show_in_menu" => true,
				"query_var" => true,
				"capability_type" => "page",
				"has_archive" => true,
				"hierarchical" => true,
				"menu_position" => null,
				"taxonomies" => array(),  
				"supports" => array("title"));
			register_post_type("app_categorie", $args);
	}
	
	/** register post for table contact **/
	public function post_type_app_contact()
	{
			$labels = array(
			"name" => _x("Contacts", "post type general name", "app-smart-web"),
			"singular_name" => _x("Contact", "post type singular name", "app-smart-web"),
			"menu_name" => _x("Contacts", "admin menu", "app-smart-web"),
			"name_admin_bar" => _x("Contacts", "add new on admin bar", "app-smart-web"),
			"add_new" => _x("Add new Contacts", "item", "app-smart-web"),
			"add_new_item" => __("Add new Contacts", "app-smart-web"),
			"new_item" => __("new item", "app-smart-web"),
			"edit_item" => __("Edit Contacts", "app-smart-web"),
			"view_item" => __("View Contacts", "app-smart-web"),
			"all_items" => __("All Contacts", "app-smart-web"),
			"search_items" => __("Search Contacts", "app-smart-web"),
			"parent_item_colon" => __("parent Contacts:", "app-smart-web"),
			"not_found" => __("not found", "app-smart-web"),
			"not_found_in_trash" => __("not found in trash", "app-smart-web"));
			$args = array(
				"labels" => $labels,
				"public" => true,
				"menu_icon" => "dashicons-tickets",
				"publicly_queryable" => false,
				"show_ui" => true,
				"show_in_menu" => true,
				"query_var" => true,
				"capability_type" => "page",
				"has_archive" => true,
				"hierarchical" => true,
				"menu_position" => null,
				"taxonomies" => array(),  
				"supports" => array("title"));
			register_post_type("app_contact", $args);
	}
	
	/** register post for table page **/
	public function post_type_app_page()
	{
			$labels = array(
			"name" => _x("Pages", "post type general name", "app-smart-web"),
			"singular_name" => _x("Page", "post type singular name", "app-smart-web"),
			"menu_name" => _x("Pages", "admin menu", "app-smart-web"),
			"name_admin_bar" => _x("Pages", "add new on admin bar", "app-smart-web"),
			"add_new" => _x("Add new Pages", "item", "app-smart-web"),
			"add_new_item" => __("Add new Pages", "app-smart-web"),
			"new_item" => __("new item", "app-smart-web"),
			"edit_item" => __("Edit Pages", "app-smart-web"),
			"view_item" => __("View Pages", "app-smart-web"),
			"all_items" => __("All Pages", "app-smart-web"),
			"search_items" => __("Search Pages", "app-smart-web"),
			"parent_item_colon" => __("parent Pages:", "app-smart-web"),
			"not_found" => __("not found", "app-smart-web"),
			"not_found_in_trash" => __("not found in trash", "app-smart-web"));
			$args = array(
				"labels" => $labels,
				"public" => true,
				"menu_icon" => "dashicons-tickets",
				"publicly_queryable" => false,
				"show_ui" => true,
				"show_in_menu" => true,
				"query_var" => true,
				"capability_type" => "page",
				"has_archive" => true,
				"hierarchical" => true,
				"menu_position" => null,
				"taxonomies" => array(),  
				"supports" => array("title"));
			register_post_type("app_page", $args);
	}
	
	/** register post for table post **/
	public function post_type_app_post()
	{
			$labels = array(
			"name" => _x("Posts", "post type general name", "app-smart-web"),
			"singular_name" => _x("Post", "post type singular name", "app-smart-web"),
			"menu_name" => _x("Posts", "admin menu", "app-smart-web"),
			"name_admin_bar" => _x("Posts", "add new on admin bar", "app-smart-web"),
			"add_new" => _x("Add new Posts", "item", "app-smart-web"),
			"add_new_item" => __("Add new Posts", "app-smart-web"),
			"new_item" => __("new item", "app-smart-web"),
			"edit_item" => __("Edit Posts", "app-smart-web"),
			"view_item" => __("View Posts", "app-smart-web"),
			"all_items" => __("All Posts", "app-smart-web"),
			"search_items" => __("Search Posts", "app-smart-web"),
			"parent_item_colon" => __("parent Posts:", "app-smart-web"),
			"not_found" => __("not found", "app-smart-web"),
			"not_found_in_trash" => __("not found in trash", "app-smart-web"));
			$args = array(
				"labels" => $labels,
				"public" => true,
				"menu_icon" => "dashicons-tickets",
				"publicly_queryable" => false,
				"show_ui" => true,
				"show_in_menu" => true,
				"query_var" => true,
				"capability_type" => "page",
				"has_archive" => true,
				"hierarchical" => true,
				"menu_position" => null,
				"taxonomies" => array(),  
				"supports" => array("title"));
			register_post_type("app_post", $args);
	}
	
	/** register post for table user **/
	public function post_type_app_user()
	{
			$labels = array(
			"name" => _x("Users", "post type general name", "app-smart-web"),
			"singular_name" => _x("User", "post type singular name", "app-smart-web"),
			"menu_name" => _x("Users", "admin menu", "app-smart-web"),
			"name_admin_bar" => _x("Users", "add new on admin bar", "app-smart-web"),
			"add_new" => _x("Add new Users", "item", "app-smart-web"),
			"add_new_item" => __("Add new Users", "app-smart-web"),
			"new_item" => __("new item", "app-smart-web"),
			"edit_item" => __("Edit Users", "app-smart-web"),
			"view_item" => __("View Users", "app-smart-web"),
			"all_items" => __("All Users", "app-smart-web"),
			"search_items" => __("Search Users", "app-smart-web"),
			"parent_item_colon" => __("parent Users:", "app-smart-web"),
			"not_found" => __("not found", "app-smart-web"),
			"not_found_in_trash" => __("not found in trash", "app-smart-web"));
			$args = array(
				"labels" => $labels,
				"public" => true,
				"menu_icon" => "dashicons-tickets",
				"publicly_queryable" => false,
				"show_ui" => true,
				"show_in_menu" => true,
				"query_var" => true,
				"capability_type" => "page",
				"has_archive" => true,
				"hierarchical" => true,
				"menu_position" => null,
				"taxonomies" => array(),  
				"supports" => array("title"));
			register_post_type("app_user", $args);
	}
	
	/** register metabox for barner **/
	public function metabox_app_barner($hook)
	{
		$allowed_hook = array("app_barner");
		if(in_array($hook, $allowed_hook))
		{
			add_meta_box("metabox_app_barner",
			   __("Barners - The REST API","app-smart-web"),
			   array($this,"metabox_app_barner_callback"),
			   $hook,
			   "normal",
			   "high");
		}
	}
	/** callback metabox for barner **/
	public function metabox_app_barner_callback($post)
	{
	     $this->smart_web_enqueue();
		wp_enqueue_style("thickbox");
		wp_nonce_field("metabox_app_barner_save","metabox_app_barner_nonce");
		printf("<pre style=\"padding:15px;margin:0;border:1px solid #eee\">");
		printf("GET ".site_url()."/wp-json/smart_web/v2/app_barner?numberposts=3\r\n");
		printf("GET ".site_url()."/wp-json/smart_web/v2/app_barner?titlerendered=[keyword]\r\n");
		printf("GET ".site_url()."/wp-json/smart_web/v2/app_barner?x_featured_media=[keyword]\r\n");
		printf("GET ".site_url()."/wp-json/smart_web/v2/app_barner?x_featured_media_original=[keyword]\r\n");
		printf("GET ".site_url()."/wp-json/smart_web/v2/app_barner?caption=[keyword]\r\n");
		printf("GET ".site_url()."/wp-json/smart_web/v2/app_barner?description=[keyword]\r\n");
		printf("GET ".site_url()."/wp-json/smart_web/v2/app_barner?x_date=[keyword]\r\n");
		printf("GET ".site_url()."/wp-json/smart_web/v2/app_barner?x_author=[keyword]\r\n");
		printf("GET ".site_url()."/wp-json/smart_web/v2/app_barner?link=[keyword]\r\n");
		printf("GET ".site_url()."/wp-json/smart_web/v2/app_barner?link=[keyword]\r\n");
		printf("</pre>");
		printf("<table class=\"form-table\">");
		$value_barner_titlerendered = get_post_meta($post->ID, "_barner_titlerendered", true);
		printf("<tr><th scope=\"row\"><label for=\"barner_titlerendered\">%s</label></th><td><input class=\"widefat\" type=\"text\" id=\"barner_titlerendered\" name=\"barner_titlerendered\" value=\"%s\" /></td></tr>",__("Title.rendered", "app-smart-web"), esc_attr($value_barner_titlerendered));
		$value_barner_x_featured_media = get_post_meta($post->ID, "_barner_x_featured_media", true);
		printf("<tr><th scope=\"row\"><label for=\"barner_x_featured_media\">%s</label></th><td><input class=\"widefat type-images\" type=\"text\" id=\"barner_x_featured_media\" name=\"barner_x_featured_media\" value=\"%s\" /></td></tr>",__("X Featured Media", "app-smart-web"), esc_attr($value_barner_x_featured_media));
		$value_barner_x_featured_media_original = get_post_meta($post->ID, "_barner_x_featured_media_original", true);
		printf("<tr><th scope=\"row\"><label for=\"barner_x_featured_media_original\">%s</label></th><td><input class=\"widefat type-images\" type=\"text\" id=\"barner_x_featured_media_original\" name=\"barner_x_featured_media_original\" value=\"%s\" /></td></tr>",__("X Featured Media Original", "app-smart-web"), esc_attr($value_barner_x_featured_media_original));
		$value_barner_caption = get_post_meta($post->ID, "_barner_caption", true);
		printf("<tr><th scope=\"row\"><label for=\"barner_caption\">%s</label></th><td><textarea class=\"widefat\" type=\"text\" id=\"barner_caption\" name=\"barner_caption\" >%s</textarea></td></tr>",__("Caption", "app-smart-web"), esc_attr($value_barner_caption));
		$value_barner_description = get_post_meta($post->ID, "_barner_description", true);
		printf("<tr><th scope=\"row\"><label for=\"barner_description\">%s</label></th><td><textarea class=\"widefat\" type=\"text\" id=\"barner_description\" name=\"barner_description\" >%s</textarea></td></tr>",__("Description", "app-smart-web"), esc_attr($value_barner_description));
		$value_barner_x_date = get_post_meta($post->ID, "_barner_x_date", true);
		printf("<tr><th scope=\"row\"><label for=\"barner_x_date\">%s</label></th><td><textarea class=\"widefat\" type=\"text\" id=\"barner_x_date\" name=\"barner_x_date\" >%s</textarea></td></tr>",__("X Date", "app-smart-web"), esc_attr($value_barner_x_date));
		$value_barner_x_author = get_post_meta($post->ID, "_barner_x_author", true);
		printf("<tr><th scope=\"row\"><label for=\"barner_x_author\">%s</label></th><td><textarea class=\"widefat\" type=\"text\" id=\"barner_x_author\" name=\"barner_x_author\" >%s</textarea></td></tr>",__("X Author", "app-smart-web"), esc_attr($value_barner_x_author));
		$value_barner_link = get_post_meta($post->ID, "_barner_link", true);
		printf("<tr><th scope=\"row\"><label for=\"barner_link\">%s</label></th><td><input class=\"widefat\" type=\"text\" id=\"barner_link\" name=\"barner_link\" value=\"%s\" /></td></tr>",__("Link", "app-smart-web"), esc_attr($value_barner_link));
		$value_barner_link = get_post_meta($post->ID, "_barner_link", true);
		printf("<tr><th scope=\"row\"><label for=\"barner_link\">%s</label></th><td><input class=\"widefat\" placeholder=\"\" type=\"url\" id=\"barner_link\" name=\"barner_link\" value=\"%s\" /></td></tr>",__("Link", "app-smart-web"), esc_attr($value_barner_link));
		printf("</table>");
		$this->ionicon_list();
	}
	public function metabox_app_barner_save($post_id)
	{
	 // Check if our nonce is set.
	 if (!isset($_POST["metabox_app_barner_nonce"]))
	 	return $post_id;
	 $nonce = $_POST["metabox_app_barner_nonce"];
	 // Verify that the nonce is valid.
	 if(!wp_verify_nonce($nonce, "metabox_app_barner_save"))
	 	return $post_id;
	 // If this is an autosave, our form has not been submitted,
	 // so we don't want to do anything.
	 if (defined("DOING_AUTOSAVE") && DOING_AUTOSAVE)
	 	return $post_id;
	 // Check the user's permissions.
	 if ("page" == $_POST["post_type"])
	 {
	 	if (!current_user_can("edit_page", $post_id))
	 		return $post_id;
	 } else
	 {
	 	if (!current_user_can("edit_post", $post_id))
	 		return $post_id;
	 }
	 // Sanitize the user input.
	 $post_barner_titlerendered = sanitize_text_field($_POST["barner_titlerendered"] );
	 // Update the meta field.
	 update_post_meta($post_id, "_barner_titlerendered", $post_barner_titlerendered);
	 // Sanitize the user input.
	 $post_barner_x_featured_media = sanitize_text_field($_POST["barner_x_featured_media"] );
	 // Update the meta field.
	 update_post_meta($post_id, "_barner_x_featured_media", $post_barner_x_featured_media);
	 // Sanitize the user input.
	 $post_barner_x_featured_media_original = sanitize_text_field($_POST["barner_x_featured_media_original"] );
	 // Update the meta field.
	 update_post_meta($post_id, "_barner_x_featured_media_original", $post_barner_x_featured_media_original);
	 // Sanitize the user input.
	 $post_barner_caption = sanitize_text_field($_POST["barner_caption"] );
	 // Update the meta field.
	 update_post_meta($post_id, "_barner_caption", $post_barner_caption);
	 // Sanitize the user input.
	 $post_barner_description = sanitize_text_field($_POST["barner_description"] );
	 // Update the meta field.
	 update_post_meta($post_id, "_barner_description", $post_barner_description);
	 // Sanitize the user input.
	 $post_barner_x_date = sanitize_text_field($_POST["barner_x_date"] );
	 // Update the meta field.
	 update_post_meta($post_id, "_barner_x_date", $post_barner_x_date);
	 // Sanitize the user input.
	 $post_barner_x_author = sanitize_text_field($_POST["barner_x_author"] );
	 // Update the meta field.
	 update_post_meta($post_id, "_barner_x_author", $post_barner_x_author);
	 // Sanitize the user input.
	 $post_barner_link = sanitize_text_field($_POST["barner_link"] );
	 // Update the meta field.
	 update_post_meta($post_id, "_barner_link", $post_barner_link);
	 // Sanitize the user input.
	 $post_barner_link = sanitize_text_field($_POST["barner_link"] );
	 // Update the meta field.
	 update_post_meta($post_id, "_barner_link", $post_barner_link);
	 }
	/** register metabox for categorie **/
	public function metabox_app_categorie($hook)
	{
		$allowed_hook = array("app_categorie");
		if(in_array($hook, $allowed_hook))
		{
			add_meta_box("metabox_app_categorie",
			   __("Categories - The REST API","app-smart-web"),
			   array($this,"metabox_app_categorie_callback"),
			   $hook,
			   "normal",
			   "high");
		}
	}
	/** callback metabox for categorie **/
	public function metabox_app_categorie_callback($post)
	{
	     $this->smart_web_enqueue();
		wp_enqueue_style("thickbox");
		wp_nonce_field("metabox_app_categorie_save","metabox_app_categorie_nonce");
		printf("<pre style=\"padding:15px;margin:0;border:1px solid #eee\">");
		printf("GET ".site_url()."/wp-json/smart_web/v2/app_categorie?numberposts=3\r\n");
		printf("GET ".site_url()."/wp-json/smart_web/v2/app_categorie?name=[keyword]\r\n");
		printf("GET ".site_url()."/wp-json/smart_web/v2/app_categorie?description=[keyword]\r\n");
		printf("GET ".site_url()."/wp-json/smart_web/v2/app_categorie?count=[keyword]\r\n");
		printf("</pre>");
		printf("<table class=\"form-table\">");
		$value_categorie_name = get_post_meta($post->ID, "_categorie_name", true);
		printf("<tr><th scope=\"row\"><label for=\"categorie_name\">%s</label></th><td><input class=\"widefat\" type=\"text\" id=\"categorie_name\" name=\"categorie_name\" value=\"%s\" /></td></tr>",__("Name", "app-smart-web"), esc_attr($value_categorie_name));
		$settings = array("media_buttons"=>true);
		$value_categorie_description = get_post_meta($post->ID, "_categorie_description", true);
		printf("<tr><th scope=\"row\"><label for=\"categorie_description\">%s</label></th><td>",__("Description","app-smart-web"));
		wp_editor(html_entity_decode($value_categorie_description),"categorie_description",$settings);
		printf("</td></tr>");
		$value_categorie_count = get_post_meta($post->ID, "_categorie_count", true);
		printf("<tr><th scope=\"row\"><label for=\"categorie_count\">%s</label></th><td><textarea class=\"widefat\" type=\"text\" id=\"categorie_count\" name=\"categorie_count\" >%s</textarea></td></tr>",__("Count", "app-smart-web"), esc_attr($value_categorie_count));
		printf("</table>");
		$this->ionicon_list();
	}
	public function metabox_app_categorie_save($post_id)
	{
	 // Check if our nonce is set.
	 if (!isset($_POST["metabox_app_categorie_nonce"]))
	 	return $post_id;
	 $nonce = $_POST["metabox_app_categorie_nonce"];
	 // Verify that the nonce is valid.
	 if(!wp_verify_nonce($nonce, "metabox_app_categorie_save"))
	 	return $post_id;
	 // If this is an autosave, our form has not been submitted,
	 // so we don't want to do anything.
	 if (defined("DOING_AUTOSAVE") && DOING_AUTOSAVE)
	 	return $post_id;
	 // Check the user's permissions.
	 if ("page" == $_POST["post_type"])
	 {
	 	if (!current_user_can("edit_page", $post_id))
	 		return $post_id;
	 } else
	 {
	 	if (!current_user_can("edit_post", $post_id))
	 		return $post_id;
	 }
	 // Sanitize the user input.
	 $post_categorie_name = sanitize_text_field($_POST["categorie_name"] );
	 // Update the meta field.
	 update_post_meta($post_id, "_categorie_name", $post_categorie_name);
	 // Sanitize the user input.
	 $post_categorie_description = esc_html($_POST["categorie_description"] );
	 // Update the meta field.
	 update_post_meta($post_id, "_categorie_description", $post_categorie_description);
	 // Sanitize the user input.
	 $post_categorie_count = sanitize_text_field($_POST["categorie_count"] );
	 // Update the meta field.
	 update_post_meta($post_id, "_categorie_count", $post_categorie_count);
	 }
	/** register metabox for contact **/
	public function metabox_app_contact($hook)
	{
		$allowed_hook = array("app_contact");
		if(in_array($hook, $allowed_hook))
		{
			add_meta_box("metabox_app_contact",
			   __("Contacts - The REST API","app-smart-web"),
			   array($this,"metabox_app_contact_callback"),
			   $hook,
			   "normal",
			   "high");
		}
	}
	/** callback metabox for contact **/
	public function metabox_app_contact_callback($post)
	{
	     $this->smart_web_enqueue();
		wp_enqueue_style("thickbox");
		wp_nonce_field("metabox_app_contact_save","metabox_app_contact_nonce");
		printf("<pre style=\"padding:15px;margin:0;border:1px solid #eee\">");
		printf("GET ".site_url()."/wp-json/smart_web/v2/app_contact?numberposts=3\r\n");
		printf("GET ".site_url()."/wp-json/smart_web/v2/app_contact?phone=[keyword]\r\n");
		printf("GET ".site_url()."/wp-json/smart_web/v2/app_contact?tital=[keyword]\r\n");
		printf("GET ".site_url()."/wp-json/smart_web/v2/app_contact?mesaage=[keyword]\r\n");
		printf("</pre>");
		printf("<table class=\"form-table\">");
		$value_contact_phone = get_post_meta($post->ID, "_contact_phone", true);
		printf("<tr><th scope=\"row\"><label for=\"contact_phone\">%s</label></th><td><input class=\"widefat\" type=\"text\" id=\"contact_phone\" name=\"contact_phone\" value=\"%s\" /></td></tr>",__("Phone", "app-smart-web"), esc_attr($value_contact_phone));
		$value_contact_tital = get_post_meta($post->ID, "_contact_tital", true);
		printf("<tr><th scope=\"row\"><label for=\"contact_tital\">%s</label></th><td><input class=\"widefat\" type=\"text\" id=\"contact_tital\" name=\"contact_tital\" value=\"%s\" /></td></tr>",__("Tital", "app-smart-web"), esc_attr($value_contact_tital));
		$settings = array("media_buttons"=>true);
		$value_contact_mesaage = get_post_meta($post->ID, "_contact_mesaage", true);
		printf("<tr><th scope=\"row\"><label for=\"contact_mesaage\">%s</label></th><td>",__("Mesaage","app-smart-web"));
		wp_editor(html_entity_decode($value_contact_mesaage),"contact_mesaage",$settings);
		printf("</td></tr>");
		printf("</table>");
		$this->ionicon_list();
	}
	public function metabox_app_contact_save($post_id)
	{
	 // Check if our nonce is set.
	 if (!isset($_POST["metabox_app_contact_nonce"]))
	 	return $post_id;
	 $nonce = $_POST["metabox_app_contact_nonce"];
	 // Verify that the nonce is valid.
	 if(!wp_verify_nonce($nonce, "metabox_app_contact_save"))
	 	return $post_id;
	 // If this is an autosave, our form has not been submitted,
	 // so we don't want to do anything.
	 if (defined("DOING_AUTOSAVE") && DOING_AUTOSAVE)
	 	return $post_id;
	 // Check the user's permissions.
	 if ("page" == $_POST["post_type"])
	 {
	 	if (!current_user_can("edit_page", $post_id))
	 		return $post_id;
	 } else
	 {
	 	if (!current_user_can("edit_post", $post_id))
	 		return $post_id;
	 }
	 // Sanitize the user input.
	 $post_contact_phone = sanitize_text_field($_POST["contact_phone"] );
	 // Update the meta field.
	 update_post_meta($post_id, "_contact_phone", $post_contact_phone);
	 // Sanitize the user input.
	 $post_contact_tital = sanitize_text_field($_POST["contact_tital"] );
	 // Update the meta field.
	 update_post_meta($post_id, "_contact_tital", $post_contact_tital);
	 // Sanitize the user input.
	 $post_contact_mesaage = esc_html($_POST["contact_mesaage"] );
	 // Update the meta field.
	 update_post_meta($post_id, "_contact_mesaage", $post_contact_mesaage);
	 }
	/** register metabox for page **/
	public function metabox_app_page($hook)
	{
		$allowed_hook = array("app_page");
		if(in_array($hook, $allowed_hook))
		{
			add_meta_box("metabox_app_page",
			   __("Pages - The REST API","app-smart-web"),
			   array($this,"metabox_app_page_callback"),
			   $hook,
			   "normal",
			   "high");
		}
	}
	/** callback metabox for page **/
	public function metabox_app_page_callback($post)
	{
	     $this->smart_web_enqueue();
		wp_enqueue_style("thickbox");
		wp_nonce_field("metabox_app_page_save","metabox_app_page_nonce");
		printf("<pre style=\"padding:15px;margin:0;border:1px solid #eee\">");
		printf("GET ".site_url()."/wp-json/smart_web/v2/app_page?numberposts=3\r\n");
		printf("GET ".site_url()."/wp-json/smart_web/v2/app_page?titlerendered=[keyword]\r\n");
		printf("GET ".site_url()."/wp-json/smart_web/v2/app_page?x_featured_media=[keyword]\r\n");
		printf("GET ".site_url()."/wp-json/smart_web/v2/app_page?x_featured_media_original=[keyword]\r\n");
		printf("GET ".site_url()."/wp-json/smart_web/v2/app_page?excerptrendered=[keyword]\r\n");
		printf("GET ".site_url()."/wp-json/smart_web/v2/app_page?contentrendered=[keyword]\r\n");
		printf("GET ".site_url()."/wp-json/smart_web/v2/app_page?x_date=[keyword]\r\n");
		printf("GET ".site_url()."/wp-json/smart_web/v2/app_page?x_author=[keyword]\r\n");
		printf("GET ".site_url()."/wp-json/smart_web/v2/app_page?link=[keyword]\r\n");
		printf("GET ".site_url()."/wp-json/smart_web/v2/app_page?link=[keyword]\r\n");
		printf("</pre>");
		printf("<table class=\"form-table\">");
		$value_page_titlerendered = get_post_meta($post->ID, "_page_titlerendered", true);
		printf("<tr><th scope=\"row\"><label for=\"page_titlerendered\">%s</label></th><td><input class=\"widefat\" type=\"text\" id=\"page_titlerendered\" name=\"page_titlerendered\" value=\"%s\" /></td></tr>",__("Title.rendered", "app-smart-web"), esc_attr($value_page_titlerendered));
		$value_page_x_featured_media = get_post_meta($post->ID, "_page_x_featured_media", true);
		printf("<tr><th scope=\"row\"><label for=\"page_x_featured_media\">%s</label></th><td><input class=\"widefat type-images\" type=\"text\" id=\"page_x_featured_media\" name=\"page_x_featured_media\" value=\"%s\" /></td></tr>",__("X Featured Media", "app-smart-web"), esc_attr($value_page_x_featured_media));
		$value_page_x_featured_media_original = get_post_meta($post->ID, "_page_x_featured_media_original", true);
		printf("<tr><th scope=\"row\"><label for=\"page_x_featured_media_original\">%s</label></th><td><input class=\"widefat type-images\" type=\"text\" id=\"page_x_featured_media_original\" name=\"page_x_featured_media_original\" value=\"%s\" /></td></tr>",__("X Featured Media Original", "app-smart-web"), esc_attr($value_page_x_featured_media_original));
		$settings = array("media_buttons"=>true);
		$value_page_excerptrendered = get_post_meta($post->ID, "_page_excerptrendered", true);
		printf("<tr><th scope=\"row\"><label for=\"page_excerptrendered\">%s</label></th><td>",__("Excerpt.rendered","app-smart-web"));
		wp_editor(html_entity_decode($value_page_excerptrendered),"page_excerptrendered",$settings);
		printf("</td></tr>");
		$settings = array("media_buttons"=>true);
		$value_page_contentrendered = get_post_meta($post->ID, "_page_contentrendered", true);
		printf("<tr><th scope=\"row\"><label for=\"page_contentrendered\">%s</label></th><td>",__("Content.rendered","app-smart-web"));
		wp_editor(html_entity_decode($value_page_contentrendered),"page_contentrendered",$settings);
		printf("</td></tr>");
		$value_page_x_date = get_post_meta($post->ID, "_page_x_date", true);
		printf("<tr><th scope=\"row\"><label for=\"page_x_date\">%s</label></th><td><textarea class=\"widefat\" type=\"text\" id=\"page_x_date\" name=\"page_x_date\" >%s</textarea></td></tr>",__("X Date", "app-smart-web"), esc_attr($value_page_x_date));
		$value_page_x_author = get_post_meta($post->ID, "_page_x_author", true);
		printf("<tr><th scope=\"row\"><label for=\"page_x_author\">%s</label></th><td><textarea class=\"widefat\" type=\"text\" id=\"page_x_author\" name=\"page_x_author\" >%s</textarea></td></tr>",__("X Author", "app-smart-web"), esc_attr($value_page_x_author));
		$value_page_link = get_post_meta($post->ID, "_page_link", true);
		printf("<tr><th scope=\"row\"><label for=\"page_link\">%s</label></th><td><input class=\"widefat\" type=\"text\" id=\"page_link\" name=\"page_link\" value=\"%s\" /></td></tr>",__("Link", "app-smart-web"), esc_attr($value_page_link));
		$value_page_link = get_post_meta($post->ID, "_page_link", true);
		printf("<tr><th scope=\"row\"><label for=\"page_link\">%s</label></th><td><input class=\"widefat\" placeholder=\"\" type=\"url\" id=\"page_link\" name=\"page_link\" value=\"%s\" /></td></tr>",__("Link", "app-smart-web"), esc_attr($value_page_link));
		printf("</table>");
		$this->ionicon_list();
	}
	public function metabox_app_page_save($post_id)
	{
	 // Check if our nonce is set.
	 if (!isset($_POST["metabox_app_page_nonce"]))
	 	return $post_id;
	 $nonce = $_POST["metabox_app_page_nonce"];
	 // Verify that the nonce is valid.
	 if(!wp_verify_nonce($nonce, "metabox_app_page_save"))
	 	return $post_id;
	 // If this is an autosave, our form has not been submitted,
	 // so we don't want to do anything.
	 if (defined("DOING_AUTOSAVE") && DOING_AUTOSAVE)
	 	return $post_id;
	 // Check the user's permissions.
	 if ("page" == $_POST["post_type"])
	 {
	 	if (!current_user_can("edit_page", $post_id))
	 		return $post_id;
	 } else
	 {
	 	if (!current_user_can("edit_post", $post_id))
	 		return $post_id;
	 }
	 // Sanitize the user input.
	 $post_page_titlerendered = sanitize_text_field($_POST["page_titlerendered"] );
	 // Update the meta field.
	 update_post_meta($post_id, "_page_titlerendered", $post_page_titlerendered);
	 // Sanitize the user input.
	 $post_page_x_featured_media = sanitize_text_field($_POST["page_x_featured_media"] );
	 // Update the meta field.
	 update_post_meta($post_id, "_page_x_featured_media", $post_page_x_featured_media);
	 // Sanitize the user input.
	 $post_page_x_featured_media_original = sanitize_text_field($_POST["page_x_featured_media_original"] );
	 // Update the meta field.
	 update_post_meta($post_id, "_page_x_featured_media_original", $post_page_x_featured_media_original);
	 // Sanitize the user input.
	 $post_page_excerptrendered = esc_html($_POST["page_excerptrendered"] );
	 // Update the meta field.
	 update_post_meta($post_id, "_page_excerptrendered", $post_page_excerptrendered);
	 // Sanitize the user input.
	 $post_page_contentrendered = esc_html($_POST["page_contentrendered"] );
	 // Update the meta field.
	 update_post_meta($post_id, "_page_contentrendered", $post_page_contentrendered);
	 // Sanitize the user input.
	 $post_page_x_date = sanitize_text_field($_POST["page_x_date"] );
	 // Update the meta field.
	 update_post_meta($post_id, "_page_x_date", $post_page_x_date);
	 // Sanitize the user input.
	 $post_page_x_author = sanitize_text_field($_POST["page_x_author"] );
	 // Update the meta field.
	 update_post_meta($post_id, "_page_x_author", $post_page_x_author);
	 // Sanitize the user input.
	 $post_page_link = sanitize_text_field($_POST["page_link"] );
	 // Update the meta field.
	 update_post_meta($post_id, "_page_link", $post_page_link);
	 // Sanitize the user input.
	 $post_page_link = sanitize_text_field($_POST["page_link"] );
	 // Update the meta field.
	 update_post_meta($post_id, "_page_link", $post_page_link);
	 }
	/** register metabox for post **/
	public function metabox_app_post($hook)
	{
		$allowed_hook = array("app_post");
		if(in_array($hook, $allowed_hook))
		{
			add_meta_box("metabox_app_post",
			   __("Posts - The REST API","app-smart-web"),
			   array($this,"metabox_app_post_callback"),
			   $hook,
			   "normal",
			   "high");
		}
	}
	/** callback metabox for post **/
	public function metabox_app_post_callback($post)
	{
	     $this->smart_web_enqueue();
		wp_enqueue_style("thickbox");
		wp_nonce_field("metabox_app_post_save","metabox_app_post_nonce");
		printf("<pre style=\"padding:15px;margin:0;border:1px solid #eee\">");
		printf("GET ".site_url()."/wp-json/smart_web/v2/app_post?numberposts=3\r\n");
		printf("GET ".site_url()."/wp-json/smart_web/v2/app_post?titlerendered=[keyword]\r\n");
		printf("GET ".site_url()."/wp-json/smart_web/v2/app_post?x_featured_media=[keyword]\r\n");
		printf("GET ".site_url()."/wp-json/smart_web/v2/app_post?x_date=[keyword]\r\n");
		printf("GET ".site_url()."/wp-json/smart_web/v2/app_post?x_author=[keyword]\r\n");
		printf("GET ".site_url()."/wp-json/smart_web/v2/app_post?x_featured_media_original=[keyword]\r\n");
		printf("GET ".site_url()."/wp-json/smart_web/v2/app_post?excerptrendered=[keyword]\r\n");
		printf("GET ".site_url()."/wp-json/smart_web/v2/app_post?contentrendered=[keyword]\r\n");
		printf("GET ".site_url()."/wp-json/smart_web/v2/app_post?x_tags=[keyword]\r\n");
		printf("GET ".site_url()."/wp-json/smart_web/v2/app_post?x_categories=[keyword]\r\n");
		printf("GET ".site_url()."/wp-json/smart_web/v2/app_post?link=[keyword]\r\n");
		printf("GET ".site_url()."/wp-json/smart_web/v2/app_post?link=[keyword]\r\n");
		printf("</pre>");
		printf("<table class=\"form-table\">");
		$value_post_titlerendered = get_post_meta($post->ID, "_post_titlerendered", true);
		printf("<tr><th scope=\"row\"><label for=\"post_titlerendered\">%s</label></th><td><input class=\"widefat\" type=\"text\" id=\"post_titlerendered\" name=\"post_titlerendered\" value=\"%s\" /></td></tr>",__("Title.rendered", "app-smart-web"), esc_attr($value_post_titlerendered));
		$value_post_x_featured_media = get_post_meta($post->ID, "_post_x_featured_media", true);
		printf("<tr><th scope=\"row\"><label for=\"post_x_featured_media\">%s</label></th><td><input class=\"widefat type-images\" type=\"text\" id=\"post_x_featured_media\" name=\"post_x_featured_media\" value=\"%s\" /></td></tr>",__("X Featured Media", "app-smart-web"), esc_attr($value_post_x_featured_media));
		$value_post_x_date = get_post_meta($post->ID, "_post_x_date", true);
		printf("<tr><th scope=\"row\"><label for=\"post_x_date\">%s</label></th><td><textarea class=\"widefat\" type=\"text\" id=\"post_x_date\" name=\"post_x_date\" >%s</textarea></td></tr>",__("X Date", "app-smart-web"), esc_attr($value_post_x_date));
		$value_post_x_author = get_post_meta($post->ID, "_post_x_author", true);
		printf("<tr><th scope=\"row\"><label for=\"post_x_author\">%s</label></th><td><textarea class=\"widefat\" type=\"text\" id=\"post_x_author\" name=\"post_x_author\" >%s</textarea></td></tr>",__("X Author", "app-smart-web"), esc_attr($value_post_x_author));
		$value_post_x_featured_media_original = get_post_meta($post->ID, "_post_x_featured_media_original", true);
		printf("<tr><th scope=\"row\"><label for=\"post_x_featured_media_original\">%s</label></th><td><input class=\"widefat type-images\" type=\"text\" id=\"post_x_featured_media_original\" name=\"post_x_featured_media_original\" value=\"%s\" /></td></tr>",__("X Featured Media Original", "app-smart-web"), esc_attr($value_post_x_featured_media_original));
		$settings = array("media_buttons"=>true);
		$value_post_excerptrendered = get_post_meta($post->ID, "_post_excerptrendered", true);
		printf("<tr><th scope=\"row\"><label for=\"post_excerptrendered\">%s</label></th><td>",__("Excerpt.rendered","app-smart-web"));
		wp_editor(html_entity_decode($value_post_excerptrendered),"post_excerptrendered",$settings);
		printf("</td></tr>");
		$settings = array("media_buttons"=>true);
		$value_post_contentrendered = get_post_meta($post->ID, "_post_contentrendered", true);
		printf("<tr><th scope=\"row\"><label for=\"post_contentrendered\">%s</label></th><td>",__("Content.rendered","app-smart-web"));
		wp_editor(html_entity_decode($value_post_contentrendered),"post_contentrendered",$settings);
		printf("</td></tr>");
		$value_post_x_tags = get_post_meta($post->ID, "_post_x_tags", true);
		printf("<tr><th scope=\"row\"><label for=\"post_x_tags\">%s</label></th><td><textarea class=\"widefat\" type=\"text\" id=\"post_x_tags\" name=\"post_x_tags\" >%s</textarea></td></tr>",__("X Tags", "app-smart-web"), esc_attr($value_post_x_tags));
		$value_post_x_categories = get_post_meta($post->ID, "_post_x_categories", true);
		printf("<tr><th scope=\"row\"><label for=\"post_x_categories\">%s</label></th><td><textarea class=\"widefat\" type=\"text\" id=\"post_x_categories\" name=\"post_x_categories\" >%s</textarea></td></tr>",__("X Categories", "app-smart-web"), esc_attr($value_post_x_categories));
		$value_post_link = get_post_meta($post->ID, "_post_link", true);
		printf("<tr><th scope=\"row\"><label for=\"post_link\">%s</label></th><td><input class=\"widefat\" type=\"text\" id=\"post_link\" name=\"post_link\" value=\"%s\" /></td></tr>",__("Link", "app-smart-web"), esc_attr($value_post_link));
		$value_post_link = get_post_meta($post->ID, "_post_link", true);
		printf("<tr><th scope=\"row\"><label for=\"post_link\">%s</label></th><td><input class=\"widefat\" placeholder=\"\" type=\"url\" id=\"post_link\" name=\"post_link\" value=\"%s\" /></td></tr>",__("Link", "app-smart-web"), esc_attr($value_post_link));
		printf("</table>");
		$this->ionicon_list();
	}
	public function metabox_app_post_save($post_id)
	{
	 // Check if our nonce is set.
	 if (!isset($_POST["metabox_app_post_nonce"]))
	 	return $post_id;
	 $nonce = $_POST["metabox_app_post_nonce"];
	 // Verify that the nonce is valid.
	 if(!wp_verify_nonce($nonce, "metabox_app_post_save"))
	 	return $post_id;
	 // If this is an autosave, our form has not been submitted,
	 // so we don't want to do anything.
	 if (defined("DOING_AUTOSAVE") && DOING_AUTOSAVE)
	 	return $post_id;
	 // Check the user's permissions.
	 if ("page" == $_POST["post_type"])
	 {
	 	if (!current_user_can("edit_page", $post_id))
	 		return $post_id;
	 } else
	 {
	 	if (!current_user_can("edit_post", $post_id))
	 		return $post_id;
	 }
	 // Sanitize the user input.
	 $post_post_titlerendered = sanitize_text_field($_POST["post_titlerendered"] );
	 // Update the meta field.
	 update_post_meta($post_id, "_post_titlerendered", $post_post_titlerendered);
	 // Sanitize the user input.
	 $post_post_x_featured_media = sanitize_text_field($_POST["post_x_featured_media"] );
	 // Update the meta field.
	 update_post_meta($post_id, "_post_x_featured_media", $post_post_x_featured_media);
	 // Sanitize the user input.
	 $post_post_x_date = sanitize_text_field($_POST["post_x_date"] );
	 // Update the meta field.
	 update_post_meta($post_id, "_post_x_date", $post_post_x_date);
	 // Sanitize the user input.
	 $post_post_x_author = sanitize_text_field($_POST["post_x_author"] );
	 // Update the meta field.
	 update_post_meta($post_id, "_post_x_author", $post_post_x_author);
	 // Sanitize the user input.
	 $post_post_x_featured_media_original = sanitize_text_field($_POST["post_x_featured_media_original"] );
	 // Update the meta field.
	 update_post_meta($post_id, "_post_x_featured_media_original", $post_post_x_featured_media_original);
	 // Sanitize the user input.
	 $post_post_excerptrendered = esc_html($_POST["post_excerptrendered"] );
	 // Update the meta field.
	 update_post_meta($post_id, "_post_excerptrendered", $post_post_excerptrendered);
	 // Sanitize the user input.
	 $post_post_contentrendered = esc_html($_POST["post_contentrendered"] );
	 // Update the meta field.
	 update_post_meta($post_id, "_post_contentrendered", $post_post_contentrendered);
	 // Sanitize the user input.
	 $post_post_x_tags = sanitize_text_field($_POST["post_x_tags"] );
	 // Update the meta field.
	 update_post_meta($post_id, "_post_x_tags", $post_post_x_tags);
	 // Sanitize the user input.
	 $post_post_x_categories = sanitize_text_field($_POST["post_x_categories"] );
	 // Update the meta field.
	 update_post_meta($post_id, "_post_x_categories", $post_post_x_categories);
	 // Sanitize the user input.
	 $post_post_link = sanitize_text_field($_POST["post_link"] );
	 // Update the meta field.
	 update_post_meta($post_id, "_post_link", $post_post_link);
	 // Sanitize the user input.
	 $post_post_link = sanitize_text_field($_POST["post_link"] );
	 // Update the meta field.
	 update_post_meta($post_id, "_post_link", $post_post_link);
	 }


	// TODO: register routes app_barner
	function register_rest_route_app_barner(){
		register_rest_route("smart_web/v2","app_barner",array(
			"methods" => "GET",
			"callback" =>array($this, "app_barner_callback"),
			"permission_callback" => function (WP_REST_Request $request){return true;}
		));
	}
	
	
	// TODO: callback routes app_barner
  function app_barner_callback($request){
      if(SMART_WEB_RESTAPI2 == true){
          $parameters = $request->get_query_params();
      }else{
          $parameters = $request;
      }
      if(isset($parameters["numberposts"])){
          $numberposts = (int) $parameters["numberposts"];
      }else{
          $numberposts =-1;
      }
      $metakey=$metavalue=null;
      if(isset($parameters["titlerendered"])){
          $metakey = "_barner_titlerendered";
          $metavalue = esc_sql($parameters["titlerendered"]);
      }
      if(isset($parameters["x_featured_media"])){
          $metakey = "_barner_x_featured_media";
          $metavalue = esc_sql($parameters["x_featured_media"]);
      }
      if(isset($parameters["x_featured_media_original"])){
          $metakey = "_barner_x_featured_media_original";
          $metavalue = esc_sql($parameters["x_featured_media_original"]);
      }
      if(isset($parameters["caption"])){
          $metakey = "_barner_caption";
          $metavalue = esc_sql($parameters["caption"]);
      }
      if(isset($parameters["description"])){
          $metakey = "_barner_description";
          $metavalue = esc_sql($parameters["description"]);
      }
      if(isset($parameters["x_date"])){
          $metakey = "_barner_x_date";
          $metavalue = esc_sql($parameters["x_date"]);
      }
      if(isset($parameters["x_author"])){
          $metakey = "_barner_x_author";
          $metavalue = esc_sql($parameters["x_author"]);
      }
      if(isset($parameters["link"])){
          $metakey = "_barner_link";
          $metavalue = esc_sql($parameters["link"]);
      }
      if(isset($parameters["link"])){
          $metakey = "_barner_link";
          $metavalue = esc_sql($parameters["link"]);
      }
      $posts = get_posts(array("post_type"=> "app_barner","post_status"=>"publish","numberposts"=> $numberposts,"meta_key"=>$metakey,"meta_value"=>$metavalue));
      foreach($posts as $post){
          $metadata[$post->ID]["id"] = $post->ID;
          $metadata[$post->ID]["titlerendered"] = get_post_meta($post->ID,"_barner_titlerendered",true);
          $metadata[$post->ID]["x_featured_media"] = get_post_meta($post->ID,"_barner_x_featured_media",true);
          $metadata[$post->ID]["x_featured_media_original"] = get_post_meta($post->ID,"_barner_x_featured_media_original",true);
          $metadata[$post->ID]["caption"] = get_post_meta($post->ID,"_barner_caption",true);
          $metadata[$post->ID]["description"] = get_post_meta($post->ID,"_barner_description",true);
          $metadata[$post->ID]["x_date"] = get_post_meta($post->ID,"_barner_x_date",true);
          $metadata[$post->ID]["x_author"] = get_post_meta($post->ID,"_barner_x_author",true);
          $metadata[$post->ID]["link"] = get_post_meta($post->ID,"_barner_link",true);
          $metadata[$post->ID]["link"] = get_post_meta($post->ID,"_barner_link",true);
      }
      if(!is_array($metadata)){$metadata = array();}
      $return = array_values($metadata);
			if(isset($_GET["id"])){
					$return = $return[0];
			}
      if (empty($metadata)){return array();}
      return $return;
  }
	/** JSON barner **/
	function ajax_app_barner(){
	     $request = $_GET;
	     $rest_api = $this->app_barner_callback($request);
	     header("Content-type: application/json");
	     header("Access-Control-Allow-Origin: *");
    if(defined("JSON_UNESCAPED_UNICODE")){
	     die(json_encode($rest_api,JSON_UNESCAPED_UNICODE));
    }else{
	     die(json_encode($rest_api));
    }
	}



	// TODO: register routes app_categorie
	function register_rest_route_app_categorie(){
		register_rest_route("smart_web/v2","app_categorie",array(
			"methods" => "GET",
			"callback" =>array($this, "app_categorie_callback"),
			"permission_callback" => function (WP_REST_Request $request){return true;}
		));
	}
	
	
	// TODO: callback routes app_categorie
  function app_categorie_callback($request){
      if(SMART_WEB_RESTAPI2 == true){
          $parameters = $request->get_query_params();
      }else{
          $parameters = $request;
      }
      if(isset($parameters["numberposts"])){
          $numberposts = (int) $parameters["numberposts"];
      }else{
          $numberposts =-1;
      }
      $metakey=$metavalue=null;
      if(isset($parameters["name"])){
          $metakey = "_categorie_name";
          $metavalue = esc_sql($parameters["name"]);
      }
      if(isset($parameters["description"])){
          $metakey = "_categorie_description";
          $metavalue = esc_sql($parameters["description"]);
      }
      if(isset($parameters["count"])){
          $metakey = "_categorie_count";
          $metavalue = esc_sql($parameters["count"]);
      }
      $posts = get_posts(array("post_type"=> "app_categorie","post_status"=>"publish","numberposts"=> $numberposts,"meta_key"=>$metakey,"meta_value"=>$metavalue));
      foreach($posts as $post){
          $metadata[$post->ID]["id"] = $post->ID;
          $metadata[$post->ID]["name"] = get_post_meta($post->ID,"_categorie_name",true);
          $metadata[$post->ID]["description"] = html_entity_decode(get_post_meta($post->ID,"_categorie_description",true));
          $metadata[$post->ID]["count"] = get_post_meta($post->ID,"_categorie_count",true);
      }
      if(!is_array($metadata)){$metadata = array();}
      $return = array_values($metadata);
			if(isset($_GET["id"])){
					$return = $return[0];
			}
      if (empty($metadata)){return array();}
      return $return;
  }
	/** JSON categorie **/
	function ajax_app_categorie(){
	     $request = $_GET;
	     $rest_api = $this->app_categorie_callback($request);
	     header("Content-type: application/json");
	     header("Access-Control-Allow-Origin: *");
    if(defined("JSON_UNESCAPED_UNICODE")){
	     die(json_encode($rest_api,JSON_UNESCAPED_UNICODE));
    }else{
	     die(json_encode($rest_api));
    }
	}



	// TODO: register routes app_contact
	function register_rest_route_app_contact(){
		register_rest_route("smart_web/v2","app_contact",array(
			"methods" => "GET",
			"callback" =>array($this, "app_contact_callback"),
			"permission_callback" => function (WP_REST_Request $request){return true;}
		));
	}
	
	
	// TODO: callback routes app_contact
  function app_contact_callback($request){
      if(SMART_WEB_RESTAPI2 == true){
          $parameters = $request->get_query_params();
      }else{
          $parameters = $request;
      }
      if(isset($parameters["numberposts"])){
          $numberposts = (int) $parameters["numberposts"];
      }else{
          $numberposts =-1;
      }
      $metakey=$metavalue=null;
      if(isset($parameters["phone"])){
          $metakey = "_contact_phone";
          $metavalue = esc_sql($parameters["phone"]);
      }
      if(isset($parameters["tital"])){
          $metakey = "_contact_tital";
          $metavalue = esc_sql($parameters["tital"]);
      }
      if(isset($parameters["mesaage"])){
          $metakey = "_contact_mesaage";
          $metavalue = esc_sql($parameters["mesaage"]);
      }
      $posts = get_posts(array("post_type"=> "app_contact","post_status"=>"publish","numberposts"=> $numberposts,"meta_key"=>$metakey,"meta_value"=>$metavalue));
      foreach($posts as $post){
          $metadata[$post->ID]["id"] = $post->ID;
          $metadata[$post->ID]["phone"] = get_post_meta($post->ID,"_contact_phone",true);
          $metadata[$post->ID]["tital"] = get_post_meta($post->ID,"_contact_tital",true);
          $metadata[$post->ID]["mesaage"] = html_entity_decode(get_post_meta($post->ID,"_contact_mesaage",true));
      }
      if(!is_array($metadata)){$metadata = array();}
      $return = array_values($metadata);
			if(isset($_GET["id"])){
					$return = $return[0];
			}
      if (empty($metadata)){return array();}
      return $return;
  }
	/** JSON contact **/
	function ajax_app_contact(){
	     $request = $_GET;
	     $rest_api = $this->app_contact_callback($request);
	     header("Content-type: application/json");
	     header("Access-Control-Allow-Origin: *");
    if(defined("JSON_UNESCAPED_UNICODE")){
	     die(json_encode($rest_api,JSON_UNESCAPED_UNICODE));
    }else{
	     die(json_encode($rest_api));
    }
	}



	// TODO: register routes app_page
	function register_rest_route_app_page(){
		register_rest_route("smart_web/v2","app_page",array(
			"methods" => "GET",
			"callback" =>array($this, "app_page_callback"),
			"permission_callback" => function (WP_REST_Request $request){return true;}
		));
	}
	
	
	// TODO: callback routes app_page
  function app_page_callback($request){
      if(SMART_WEB_RESTAPI2 == true){
          $parameters = $request->get_query_params();
      }else{
          $parameters = $request;
      }
      if(isset($parameters["numberposts"])){
          $numberposts = (int) $parameters["numberposts"];
      }else{
          $numberposts =-1;
      }
      $metakey=$metavalue=null;
      if(isset($parameters["titlerendered"])){
          $metakey = "_page_titlerendered";
          $metavalue = esc_sql($parameters["titlerendered"]);
      }
      if(isset($parameters["x_featured_media"])){
          $metakey = "_page_x_featured_media";
          $metavalue = esc_sql($parameters["x_featured_media"]);
      }
      if(isset($parameters["x_featured_media_original"])){
          $metakey = "_page_x_featured_media_original";
          $metavalue = esc_sql($parameters["x_featured_media_original"]);
      }
      if(isset($parameters["excerptrendered"])){
          $metakey = "_page_excerptrendered";
          $metavalue = esc_sql($parameters["excerptrendered"]);
      }
      if(isset($parameters["contentrendered"])){
          $metakey = "_page_contentrendered";
          $metavalue = esc_sql($parameters["contentrendered"]);
      }
      if(isset($parameters["x_date"])){
          $metakey = "_page_x_date";
          $metavalue = esc_sql($parameters["x_date"]);
      }
      if(isset($parameters["x_author"])){
          $metakey = "_page_x_author";
          $metavalue = esc_sql($parameters["x_author"]);
      }
      if(isset($parameters["link"])){
          $metakey = "_page_link";
          $metavalue = esc_sql($parameters["link"]);
      }
      if(isset($parameters["link"])){
          $metakey = "_page_link";
          $metavalue = esc_sql($parameters["link"]);
      }
      $posts = get_posts(array("post_type"=> "app_page","post_status"=>"publish","numberposts"=> $numberposts,"meta_key"=>$metakey,"meta_value"=>$metavalue));
      foreach($posts as $post){
          $metadata[$post->ID]["id"] = $post->ID;
          $metadata[$post->ID]["titlerendered"] = get_post_meta($post->ID,"_page_titlerendered",true);
          $metadata[$post->ID]["x_featured_media"] = get_post_meta($post->ID,"_page_x_featured_media",true);
          $metadata[$post->ID]["x_featured_media_original"] = get_post_meta($post->ID,"_page_x_featured_media_original",true);
          $metadata[$post->ID]["excerptrendered"] = html_entity_decode(get_post_meta($post->ID,"_page_excerptrendered",true));
          $metadata[$post->ID]["contentrendered"] = html_entity_decode(get_post_meta($post->ID,"_page_contentrendered",true));
          $metadata[$post->ID]["x_date"] = get_post_meta($post->ID,"_page_x_date",true);
          $metadata[$post->ID]["x_author"] = get_post_meta($post->ID,"_page_x_author",true);
          $metadata[$post->ID]["link"] = get_post_meta($post->ID,"_page_link",true);
          $metadata[$post->ID]["link"] = get_post_meta($post->ID,"_page_link",true);
      }
      if(!is_array($metadata)){$metadata = array();}
      $return = array_values($metadata);
			if(isset($_GET["id"])){
					$return = $return[0];
			}
      if (empty($metadata)){return array();}
      return $return;
  }
	/** JSON page **/
	function ajax_app_page(){
	     $request = $_GET;
	     $rest_api = $this->app_page_callback($request);
	     header("Content-type: application/json");
	     header("Access-Control-Allow-Origin: *");
    if(defined("JSON_UNESCAPED_UNICODE")){
	     die(json_encode($rest_api,JSON_UNESCAPED_UNICODE));
    }else{
	     die(json_encode($rest_api));
    }
	}



	// TODO: register routes app_post
	function register_rest_route_app_post(){
		register_rest_route("smart_web/v2","app_post",array(
			"methods" => "GET",
			"callback" =>array($this, "app_post_callback"),
			"permission_callback" => function (WP_REST_Request $request){return true;}
		));
	}
	
	
	// TODO: callback routes app_post
  function app_post_callback($request){
      if(SMART_WEB_RESTAPI2 == true){
          $parameters = $request->get_query_params();
      }else{
          $parameters = $request;
      }
      if(isset($parameters["numberposts"])){
          $numberposts = (int) $parameters["numberposts"];
      }else{
          $numberposts =-1;
      }
      $metakey=$metavalue=null;
      if(isset($parameters["titlerendered"])){
          $metakey = "_post_titlerendered";
          $metavalue = esc_sql($parameters["titlerendered"]);
      }
      if(isset($parameters["x_featured_media"])){
          $metakey = "_post_x_featured_media";
          $metavalue = esc_sql($parameters["x_featured_media"]);
      }
      if(isset($parameters["x_date"])){
          $metakey = "_post_x_date";
          $metavalue = esc_sql($parameters["x_date"]);
      }
      if(isset($parameters["x_author"])){
          $metakey = "_post_x_author";
          $metavalue = esc_sql($parameters["x_author"]);
      }
      if(isset($parameters["x_featured_media_original"])){
          $metakey = "_post_x_featured_media_original";
          $metavalue = esc_sql($parameters["x_featured_media_original"]);
      }
      if(isset($parameters["excerptrendered"])){
          $metakey = "_post_excerptrendered";
          $metavalue = esc_sql($parameters["excerptrendered"]);
      }
      if(isset($parameters["contentrendered"])){
          $metakey = "_post_contentrendered";
          $metavalue = esc_sql($parameters["contentrendered"]);
      }
      if(isset($parameters["x_tags"])){
          $metakey = "_post_x_tags";
          $metavalue = esc_sql($parameters["x_tags"]);
      }
      if(isset($parameters["x_categories"])){
          $metakey = "_post_x_categories";
          $metavalue = esc_sql($parameters["x_categories"]);
      }
      if(isset($parameters["link"])){
          $metakey = "_post_link";
          $metavalue = esc_sql($parameters["link"]);
      }
      if(isset($parameters["link"])){
          $metakey = "_post_link";
          $metavalue = esc_sql($parameters["link"]);
      }
      $posts = get_posts(array("post_type"=> "app_post","post_status"=>"publish","numberposts"=> $numberposts,"meta_key"=>$metakey,"meta_value"=>$metavalue));
      foreach($posts as $post){
          $metadata[$post->ID]["id"] = $post->ID;
          $metadata[$post->ID]["titlerendered"] = get_post_meta($post->ID,"_post_titlerendered",true);
          $metadata[$post->ID]["x_featured_media"] = get_post_meta($post->ID,"_post_x_featured_media",true);
          $metadata[$post->ID]["x_date"] = get_post_meta($post->ID,"_post_x_date",true);
          $metadata[$post->ID]["x_author"] = get_post_meta($post->ID,"_post_x_author",true);
          $metadata[$post->ID]["x_featured_media_original"] = get_post_meta($post->ID,"_post_x_featured_media_original",true);
          $metadata[$post->ID]["excerptrendered"] = html_entity_decode(get_post_meta($post->ID,"_post_excerptrendered",true));
          $metadata[$post->ID]["contentrendered"] = html_entity_decode(get_post_meta($post->ID,"_post_contentrendered",true));
          $metadata[$post->ID]["x_tags"] = get_post_meta($post->ID,"_post_x_tags",true);
          $metadata[$post->ID]["x_categories"] = get_post_meta($post->ID,"_post_x_categories",true);
          $metadata[$post->ID]["link"] = get_post_meta($post->ID,"_post_link",true);
          $metadata[$post->ID]["link"] = get_post_meta($post->ID,"_post_link",true);
      }
      if(!is_array($metadata)){$metadata = array();}
      $return = array_values($metadata);
			if(isset($_GET["id"])){
					$return = $return[0];
			}
      if (empty($metadata)){return array();}
      return $return;
  }
	/** JSON post **/
	function ajax_app_post(){
	     $request = $_GET;
	     $rest_api = $this->app_post_callback($request);
	     header("Content-type: application/json");
	     header("Access-Control-Allow-Origin: *");
    if(defined("JSON_UNESCAPED_UNICODE")){
	     die(json_encode($rest_api,JSON_UNESCAPED_UNICODE));
    }else{
	     die(json_encode($rest_api));
    }
	}


	/** Register rest router for form request contact **/
	function register_rest_route_app_contact_submit(){
      register_rest_route("smart_web/v2","app_contact_submit",array(
          "methods" => "POST",
          "callback" =>array($this, "app_contact_submit_callback"),
          "permission_callback" => function (WP_REST_Request $request){return true;}
      ));
	}

	/** callback rest router contact **/
   function app_contact_submit_callback($request){
		$parameters = $_POST;
		//prepare data post
		$new_post_arg = array(
			"post_title" => "form app contact",
			"post_content" => "",
			"post_status" => "pending", // (draft|publish|pending|future|private)
			"post_type" => "app_contact",
		); 
		//insert data post to database
		$new_post_id = wp_insert_post($new_post_arg);
		if($new_post_id){
		include( ABSPATH . "wp-admin/includes/image.php");
		//now you can use $post_id within add_post_meta or update_post_meta 
			if(isset($parameters["phone"])){
				$metavalue_phone = wp_strip_all_tags($parameters["phone"]);
				if(!add_post_meta($new_post_id ,"_contact_phone", $metavalue_phone, true)){
					update_post_meta($new_post_id , "_contact_phone", $metavalue_phone); 
				}
			}
			if(isset($parameters["tital"])){
				$metavalue_tital = wp_strip_all_tags($parameters["tital"]);
				if(!add_post_meta($new_post_id ,"_contact_tital", $metavalue_tital, true)){
					update_post_meta($new_post_id , "_contact_tital", $metavalue_tital); 
				}
			}
			if(isset($parameters["mesaage"])){
				$metavalue_mesaage = wp_strip_all_tags($parameters["mesaage"]);
				if(!add_post_meta($new_post_id ,"_contact_mesaage", $metavalue_mesaage, true)){
					update_post_meta($new_post_id , "_contact_mesaage", $metavalue_mesaage); 
				}
			}
			$data["message"] = "Your request has been sent.";
			$data["title"] = "Successfully";
		}else{
			$data["message"] = "Please! complete the form provided.";
			$data["title"] = "Notice!";
		}
		return $data;
	}

	/** JSON contact **/
	function ajax_app_contact_submit(){
		$rest_api = $this->app_contact_submit_callback($POST);
		header("Content-type: application/json");
		header("Access-Control-Allow-Origin: *");
		if(defined("JSON_UNESCAPED_UNICODE")){
			die(json_encode($rest_api,JSON_UNESCAPED_UNICODE));
		}else{
			die(json_encode($rest_api));
		}
	}
	
	/** register css/js smart web **/
	public function smart_web_enqueue()
	{
	  	wp_enqueue_media();
	     wp_register_style("ionicon", "//code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css",array(),"1.2.4" );
	     wp_enqueue_style("ionicon");
	     wp_enqueue_script("app_smart_web", plugins_url("/",__FILE__) . "/js/admin.js", array("jquery","thickbox"),"1",true );
	}
	
	public function ionicon_list(){
		$icons = "alert,alert-circled,android-add,android-add-circle,android-alarm-clock,android-alert,android-apps,android-archive,android-arrow-back,android-arrow-down,android-arrow-dropdown,android-arrow-dropdown-circle,android-arrow-dropleft,android-arrow-dropleft-circle,android-arrow-dropright,android-arrow-dropright-circle,android-arrow-dropup,android-arrow-dropup-circle,android-arrow-forward,android-arrow-up,android-attach,android-bar,android-bicycle,android-boat,android-bookmark,android-bulb,android-bus,android-calendar,android-call,android-camera,android-cancel,android-car,android-cart,android-chat,android-checkbox,android-checkbox-blank,android-checkbox-outline,android-checkbox-outline-blank,android-checkmark-circle,android-clipboard,android-close,android-cloud,android-cloud-circle,android-cloud-done,android-cloud-outline,android-color-palette,android-compass,android-contact,android-contacts,android-contract,android-create,android-delete,android-desktop,android-document,android-done,android-done-all,android-download,android-drafts,android-exit,android-expand,android-favorite,android-favorite-outline,android-film,android-folder,android-folder-open,android-funnel,android-globe,android-hand,android-hangout,android-happy,android-home,android-image,android-laptop,android-list,android-locate,android-lock,android-mail,android-map,android-menu,android-microphone,android-microphone-off,android-more-horizontal,android-more-vertical,android-navigate,android-notifications,android-notifications-none,android-notifications-off,android-open,android-options,android-people,android-person,android-person-add,android-phone-landscape,android-phone-portrait,android-pin,android-plane,android-playstore,android-print,android-radio-button-off,android-radio-button-on,android-refresh,android-remove,android-remove-circle,android-restaurant,android-sad,android-search,android-send,android-settings,android-share,android-share-alt,android-star,android-star-half,android-star-outline,android-stopwatch,android-subway,android-sunny,android-sync,android-textsms,android-time,android-train,android-unlock,android-upload,android-volume-down,android-volume-mute,android-volume-off,android-volume-up,android-walk,android-warning,android-watch,android-wifi,aperture,archive,arrow-down-a,arrow-down-b,arrow-down-c,arrow-expand,arrow-graph-down-left,arrow-graph-down-right,arrow-graph-up-left,arrow-graph-up-right,arrow-left-a,arrow-left-b,arrow-left-c,arrow-move,arrow-resize,arrow-return-left,arrow-return-right,arrow-right-a,arrow-right-b,arrow-right-c,arrow-shrink,arrow-swap,arrow-up-a,arrow-up-b,arrow-up-c,asterisk,at,backspace,backspace-outline,bag,battery-charging,battery-empty,battery-full,battery-half,battery-low,beaker,beer,bluetooth,bonfire,bookmark,bowtie,briefcase,bug,calculator,calendar,camera,card,cash,chatbox,chatbox-working,chatboxes,chatbubble,chatbubble-working,chatbubbles,checkmark,checkmark-circled,checkmark-round,chevron-down,chevron-left,chevron-right,chevron-up,clipboard,clock,close,close-circled,close-round,closed-captioning,cloud,code,code-download,code-working,coffee,compass,compose,connection-bars,contrast,crop,cube,disc,document,document-text,drag,earth,easel,edit,egg,eject,email,email-unread,erlenmeyer-flask,erlenmeyer-flask-bubbles,eye,eye-disabled,female,filing,film-marker,fireball,flag,flame,flash,flash-off,folder,fork,fork-repo,forward,funnel,gear-a,gear-b,grid,hammer,happy,happy-outline,headphone,heart,heart-broken,help,help-buoy,help-circled,home,icecream,image,images,information,information-circled,ionic,ios-alarm,ios-alarm-outline,ios-albums,ios-albums-outline,ios-americanfootball,ios-americanfootball-outline,ios-analytics,ios-analytics-outline,ios-arrow-back,ios-arrow-down,ios-arrow-forward,ios-arrow-left,ios-arrow-right,ios-arrow-thin-down,ios-arrow-thin-left,ios-arrow-thin-right,ios-arrow-thin-up,ios-arrow-up,ios-at,ios-at-outline,ios-barcode,ios-barcode-outline,ios-baseball,ios-baseball-outline,ios-basketball,ios-basketball-outline,ios-bell,ios-bell-outline,ios-body,ios-body-outline,ios-bolt,ios-bolt-outline,ios-book,ios-book-outline,ios-bookmarks,ios-bookmarks-outline,ios-box,ios-box-outline,ios-briefcase,ios-briefcase-outline,ios-browsers,ios-browsers-outline,ios-calculator,ios-calculator-outline,ios-calendar,ios-calendar-outline,ios-camera,ios-camera-outline,ios-cart,ios-cart-outline,ios-chatboxes,ios-chatboxes-outline,ios-chatbubble,ios-chatbubble-outline,ios-checkmark,ios-checkmark-empty,ios-checkmark-outline,ios-circle-filled,ios-circle-outline,ios-clock,ios-clock-outline,ios-close,ios-close-empty,ios-close-outline,ios-cloud,ios-cloud-download,ios-cloud-download-outline,ios-cloud-outline,ios-cloud-upload,ios-cloud-upload-outline,ios-cloudy,ios-cloudy-night,ios-cloudy-night-outline,ios-cloudy-outline,ios-cog,ios-cog-outline,ios-color-filter,ios-color-filter-outline,ios-color-wand,ios-color-wand-outline,ios-compose,ios-compose-outline,ios-contact,ios-contact-outline,ios-copy,ios-copy-outline,ios-crop,ios-crop-strong,ios-download,ios-download-outline,ios-drag,ios-email,ios-email-outline,ios-eye,ios-eye-outline,ios-fastforward,ios-fastforward-outline,ios-filing,ios-filing-outline,ios-film,ios-film-outline,ios-flag,ios-flag-outline,ios-flame,ios-flame-outline,ios-flask,ios-flask-outline,ios-flower,ios-flower-outline,ios-folder,ios-folder-outline,ios-football,ios-football-outline,ios-game-controller-a,ios-game-controller-a-outline,ios-game-controller-b,ios-game-controller-b-outline,ios-gear,ios-gear-outline,ios-glasses,ios-glasses-outline,ios-grid-view,ios-grid-view-outline,ios-heart,ios-heart-outline,ios-help,ios-help-empty,ios-help-outline,ios-home,ios-home-outline,ios-infinite,ios-infinite-outline,ios-information,ios-information-empty,ios-information-outline,ios-ionic-outline,ios-keypad,ios-keypad-outline,ios-lightbulb,ios-lightbulb-outline,ios-list,ios-list-outline,ios-location,ios-location-outline,ios-locked,ios-locked-outline,ios-loop,ios-loop-strong,ios-medical,ios-medical-outline,ios-medkit,ios-medkit-outline,ios-mic,ios-mic-off,ios-mic-outline,ios-minus,ios-minus-empty,ios-minus-outline,ios-monitor,ios-monitor-outline,ios-moon,ios-moon-outline,ios-more,ios-more-outline,ios-musical-note,ios-musical-notes,ios-navigate,ios-navigate-outline,ios-nutrition,ios-nutrition-outline,ios-paper,ios-paper-outline,ios-paperplane,ios-paperplane-outline,ios-partlysunny,ios-partlysunny-outline,ios-pause,ios-pause-outline,ios-paw,ios-paw-outline,ios-people,ios-people-outline,ios-person,ios-person-outline,ios-personadd,ios-personadd-outline,ios-photos,ios-photos-outline,ios-pie,ios-pie-outline,ios-pint,ios-pint-outline,ios-play,ios-play-outline,ios-plus,ios-plus-empty,ios-plus-outline,ios-pricetag,ios-pricetag-outline,ios-pricetags,ios-pricetags-outline,ios-printer,ios-printer-outline,ios-pulse,ios-pulse-strong,ios-rainy,ios-rainy-outline,ios-recording,ios-recording-outline,ios-redo,ios-redo-outline,ios-refresh,ios-refresh-empty,ios-refresh-outline,ios-reload,ios-reverse-camera,ios-reverse-camera-outline,ios-rewind,ios-rewind-outline,ios-rose,ios-rose-outline,ios-search,ios-search-strong,ios-settings,ios-settings-strong,ios-shuffle,ios-shuffle-strong,ios-skipbackward,ios-skipbackward-outline,ios-skipforward,ios-skipforward-outline,ios-snowy,ios-speedometer,ios-speedometer-outline,ios-star,ios-star-half,ios-star-outline,ios-stopwatch,ios-stopwatch-outline,ios-sunny,ios-sunny-outline,ios-telephone,ios-telephone-outline,ios-tennisball,ios-tennisball-outline,ios-thunderstorm,ios-thunderstorm-outline,ios-time,ios-time-outline,ios-timer,ios-timer-outline,ios-toggle,ios-toggle-outline,ios-trash,ios-trash-outline,ios-undo,ios-undo-outline,ios-unlocked,ios-unlocked-outline,ios-upload,ios-upload-outline,ios-videocam,ios-videocam-outline,ios-volume-high,ios-volume-low,ios-wineglass,ios-wineglass-outline,ios-world,ios-world-outline,ipad,iphone,ipod,jet,key,knife,laptop,leaf,levels,lightbulb,link,load-a,load-b,load-c,load-d,location,lock-combination,locked,log-in,log-out,loop,magnet,male,man,map,medkit,merge,mic-a,mic-b,mic-c,minus,minus-circled,minus-round,model-s,monitor,more,mouse,music-note,navicon,navicon-round,navigate,network,no-smoking,nuclear,outlet,paintbrush,paintbucket,paper-airplane,paperclip,pause,person,person-add,person-stalker,pie-graph,pin,pinpoint,pizza,plane,planet,play,playstation,plus,plus-circled,plus-round,podium,pound,power,pricetag,pricetags,printer,pull-request,qr-scanner,quote,radio-waves,record,refresh,reply,reply-all,ribbon-a,ribbon-b,sad,sad-outline,scissors,search,settings,share,shuffle,skip-backward,skip-forward,social-android,social-android-outline,social-angular,social-angular-outline,social-apple,social-apple-outline,social-bitcoin,social-bitcoin-outline,social-buffer,social-buffer-outline,social-chrome,social-chrome-outline,social-codepen,social-codepen-outline,social-css3,social-css3-outline,social-designernews,social-designernews-outline,social-dribbble,social-dribbble-outline,social-dropbox,social-dropbox-outline,social-euro,social-euro-outline,social-facebook,social-facebook-outline,social-foursquare,social-foursquare-outline,social-freebsd-devil,social-github,social-github-outline,social-google,social-google-outline,social-googleplus,social-googleplus-outline,social-hackernews,social-hackernews-outline,social-html5,social-html5-outline,social-instagram,social-instagram-outline,social-javascript,social-javascript-outline,social-linkedin,social-linkedin-outline,social-markdown,social-nodejs,social-octocat,social-pinterest,social-pinterest-outline,social-python,social-reddit,social-reddit-outline,social-rss,social-rss-outline,social-sass,social-skype,social-skype-outline,social-snapchat,social-snapchat-outline,social-tumblr,social-tumblr-outline,social-tux,social-twitch,social-twitch-outline,social-twitter,social-twitter-outline,social-usd,social-usd-outline,social-vimeo,social-vimeo-outline,social-whatsapp,social-whatsapp-outline,social-windows,social-windows-outline,social-wordpress,social-wordpress-outline,social-yahoo,social-yahoo-outline,social-yen,social-yen-outline,social-youtube,social-youtube-outline,soup-can,soup-can-outline,speakerphone,speedometer,spoon,star,stats-bars,steam,stop,thermometer,thumbsdown,thumbsup,toggle,toggle-filled,transgender,trash-a,trash-b,trophy,tshirt,tshirt-outline,umbrella,university,unlocked,upload,usb,videocamera,volume-high,volume-low,volume-medium,volume-mute,wand,waterdrop,wifi,wineglass,woman,wrench,xbox";
		print("<div id=\"ionicons\" style=\"display:none;\">");
		print("<div style=\"width: 100%;height:490px;overflow-x: scroll;\">");
		foreach(explode(",",$icons) as $icon){
		    print("<a class=\"app_smart_web_ionicons\" ><i class=\"ion ion-".$icon."\"></i></a>");
		}
		print("</div>");
		print("</div>");
	}


	function admin_head_app_smart_web($hooks){
	     echo "<style type=\"text/css\">";
	     echo ".app_smart_web_ionicons .ion{cursor:pointer;text-align:center;border:1px solid #eee;font-size:32px;width:32px;height:32px;padding:6px;}";
	     echo "</style>";
	}


}
new AppSmartWeb();
