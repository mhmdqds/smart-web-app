Create a file POT, PO and MO using POEdit or Loco Translate Plugin, 
then rename accordance with textdomain used by the plugin, as follows:
* app_smart-web-de_DE.po
* app_smart-web-id_ID.po
* app_smart-web_ES.po
* app_smart-web-en_US.po
* app_smart-web-de_DE.mo
* app_smart-web-id_ID.mo
* app_smart-web-es_ES.mo
* app_smart-web-en_US.mo
Download:
* http://wordpress.org/extend/plugins/loco-translate
* http://poedit.net/download
